# AutoSaleVPS Version

当前版本（vYYYYMMDDHHmm）：v202512012312
短格式（vyymmddhhmm）：v2512012312
生成时间：2025-12-01T15:12:48.817Z

该文件会在执行 npm run package 时同步为最新打包版本。
