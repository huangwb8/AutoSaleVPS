# AutoSaleVPS Version

当前版本（vYYYYMMDDHHmm）：v202512012254
短格式（vyymmddhhmm）：v2512012254
生成时间：2025-12-01T14:54:54.015Z

该文件会在执行 npm run package 时同步为最新打包版本。
