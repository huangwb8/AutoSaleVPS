# AutoSaleVPS Version

当前版本（vYYYYMMDDHHmm）：v202512131411
短格式（vyymmddhhmm）：v2512131411
生成时间：2025-12-13T06:11:52.187Z

该文件会在执行 npm run package 时同步为最新打包版本。
