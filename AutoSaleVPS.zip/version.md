# AutoSaleVPS Version

当前版本（vYYYYMMDDHHmm）：v202512011837
短格式（vyymmddhhmm）：v2512011837
生成时间：2025-12-01T10:37:52.937Z

该文件会在执行 npm run package 时同步为最新打包版本。
