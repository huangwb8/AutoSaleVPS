<?php
/**
 * Config repository utilities.
 *
 * @package AutoSaleVPS
 */

require_once __DIR__ . '/class-asv-toml.php';

if ( ! class_exists( 'ASV_Config_Repository' ) ) {
		class ASV_Config_Repository {
			const OPTION_API_KEY         = 'autosalevps_api_key';
			const OPTION_TIMEZONE        = 'autosalevps_timezone';
			const OPTION_STATUSES        = 'autosalevps_statuses';
			const OPTION_PROMO_CACHE     = 'autosalevps_promos';
			const OPTION_PROMO_OVERRIDES = 'autosalevps_promo_overrides';
			const OPTION_EXTRA_CSS       = 'autosalevps_extra_css';
			const OPTION_META_CACHE      = 'autosalevps_meta_cache';
			const OPTION_META_OVERRIDES  = 'autosalevps_meta_overrides';
			const OPTION_VPS_SNAPSHOT    = 'autosalevps_vps_snapshot';
			const DEFAULT_TIMEZONE       = 'Asia/Shanghai';
			const LOG_FILENAME           = 'autosalevps.log';

		/**
		 * Config path.
		 *
		 * @var string
		 */
		protected $config_path;

		/**
		 * Model path.
		 *
		 * @var string
		 */
		protected $model_path;

		/**
		 * Log file path.
		 *
		 * @var string
		 */
		protected $log_path;

		/**
		 * Constructor.
		 *
		 * @param string $config_path Config path.
		 * @param string $model_path  Model path.
		 */
		public function __construct( $config_path, $model_path ) {
			$this->config_path = $config_path;
			$this->model_path  = $model_path;
			$this->log_path    = trailingslashit( dirname( $config_path ) ) . self::LOG_FILENAME;
		}

		/**
		 * Return raw config.
		 *
		 * @return string
		 */
		public function get_config_raw() {
			return (string) $this->read_file( $this->config_path );
		}

		/**
		 * Persist config.
		 *
		 * @param string $content Config contents.
		 */
		public function save_config_raw( $content ) {
			$this->write_file( $this->config_path, (string) $content );
		}

		/**
		 * Raw model file.
		 *
		 * @return string
		 */
		public function get_model_raw() {
			return (string) $this->read_file( $this->model_path );
		}

		/**
		 * Save model file.
		 *
		 * @param string $content File body.
		 */
		public function save_model_raw( $content ) {
			$this->write_file( $this->model_path, (string) $content );
		}

		/**
		 * Read parsed config.
		 *
		 * @return array
		 */
		public function get_config() {
			return ASV_TOML_Parser::parse( $this->get_config_raw() );
		}

		/**
		 * Parsed model file.
		 *
		 * @return array
		 */
		public function get_model() {
			return ASV_TOML_Parser::parse( $this->get_model_raw() );
		}

		/**
		 * Build Vps definitions from config.
		 *
		 * @return array
		 */
		public function get_vps_definitions() {
			$config   = $this->get_config();
			$vps_tree = isset( $config['vps'] ) && is_array( $config['vps'] ) ? $config['vps'] : array();
			$urls     = isset( $config['url'] ) && is_array( $config['url'] ) ? $config['url'] : array();
			$aff      = isset( $config['aff'] ) && is_array( $config['aff'] ) ? $config['aff'] : array();
			$result   = array();

			foreach ( $vps_tree as $vendor => $group ) {
				if ( ! is_array( $group ) ) {
					continue;
				}

				foreach ( $group as $pid => $details ) {
					$pid_value = isset( $details['pid'] ) ? (string) $details['pid'] : (string) $pid;
					$result[]  = array(
						'vendor'        => (string) $vendor,
						'pid'           => $pid_value,
						'human_comment' => isset( $details['human_comment'] ) ? (string) $details['human_comment'] : '',
						'sale_url'      => $this->build_url( $urls, $aff, $vendor, $pid_value, 'sale_format' ),
						'valid_url'     => $this->build_url( $urls, $aff, $vendor, $pid_value, 'valid_format' ),
						'interval'      => $this->extract_interval( $urls, $vendor ),
						'valid_delay'   => $this->extract_valid_delay( $urls, $vendor ),
					);
				}
			}

			return $result;
		}

		/**
		 * Build a URL using template.
		 *
		 * @param array  $urls    Url configuration.
		 * @param array  $aff     Affiliate codes.
		 * @param string $vendor  Vendor key.
		 * @param string $pid     Product id.
		 * @param string $key     Template key.
		 * @return string
		 */
		protected function build_url( $urls, $aff, $vendor, $pid, $key ) {
			if ( empty( $urls[ $vendor ][ $key ] ) ) {
				return '';
			}

			$aff_code = '';
			if ( ! empty( $aff[ $vendor ] ) && is_array( $aff[ $vendor ] ) ) {
				$aff_values = $aff[ $vendor ];
				$aff_code   = isset( $aff_values['code'] ) ? (string) $aff_values['code'] : implode( '', $aff_values );
			}

			$template = (string) $urls[ $vendor ][ $key ];
			return str_replace(
				array( '{aff}', '{pid}' ),
				array( rawurlencode( $aff_code ), rawurlencode( $pid ) ),
				$template
			);
		}

		/**
		 * Extract validation interval in seconds.
		 *
		 * @param array  $urls   Url config tree.
		 * @param string $vendor Vendor key.
		 * @return int
		 */
		protected function extract_interval( $urls, $vendor ) {
			if ( empty( $urls[ $vendor ]['valid_interval_time'] ) ) {
				return DAY_IN_SECONDS;
			}

			return (int) $urls[ $vendor ]['valid_interval_time'];
		}

		/**
		 * Extract a valid delay range.
		 *
		 * @param array  $urls   Url config.
		 * @param string $vendor Vendor key.
		 * @return array [min, max]
		 */
		protected function extract_valid_delay( $urls, $vendor ) {
			$raw = isset( $urls[ $vendor ]['valid_vps_time'] ) ? (string) $urls[ $vendor ]['valid_vps_time'] : '5-10';
			if ( false === strpos( $raw, '-' ) ) {
				$seconds = max( 1, (int) $raw );
				return array( $seconds, $seconds );
			}

			list( $min, $max ) = array_map( 'trim', explode( '-', $raw, 2 ) );
			$min               = max( 1, (int) $min );
			$max               = max( $min, (int) $max );
			return array( $min, $max );
		}

		/**
		 * Read a file safely.
		 *
		 * @param string $path File path.
		 * @return string
		 */
		protected function read_file( $path ) {
			if ( ! file_exists( $path ) ) {
				return '';
			}

			return (string) file_get_contents( $path );
		}

		/**
		 * Write file contents.
		 *
		 * @param string $path    File path.
		 * @param string $content Content.
		 */
		protected function write_file( $path, $content ) {
			wp_mkdir_p( dirname( $path ) );
			file_put_contents( $path, $content, LOCK_EX );
		}

		/**
		 * Fetch stored API key.
		 *
		 * @return string
		 */
		public function get_api_key() {
			return (string) get_option( self::OPTION_API_KEY, '' );
		}

		/**
		 * Save API key.
		 *
		 * @param string $key Secret.
		 */
		public function save_api_key( $key ) {
			update_option( self::OPTION_API_KEY, (string) $key );
		}

		/**
		 * Return timezone.
		 *
		 * @return string
		 */
		public function get_timezone() {
			return (string) get_option( self::OPTION_TIMEZONE, self::DEFAULT_TIMEZONE );
		}

		/**
		 * Update timezone.
		 *
		 * @param string $timezone Timezone id.
		 */
		public function save_timezone( $timezone ) {
			update_option( self::OPTION_TIMEZONE, (string) $timezone );
		}

		/**
		 * Persist statuses.
		 *
		 * @param array $statuses Status payload.
		 */
		public function save_statuses( $statuses ) {
			update_option( self::OPTION_STATUSES, $statuses );
		}

		/**
		 * Get saved statuses.
		 *
		 * @return array
		 */
		public function get_statuses() {
			$statuses = get_option( self::OPTION_STATUSES, array() );
			return is_array( $statuses ) ? $statuses : array();
		}

	/**
	 * Save manual promo overrides.
	 *
	 * @param string $vendor  Vendor key.
	 * @param string $pid     Product id.
	 * @param string $content Promo text.
	 */
		public function save_promo_override( $vendor, $pid, $content ) {
			$overrides = $this->get_promo_overrides();
			$key       = $this->build_vps_key( $vendor, $pid );
			$body      = trim( (string) $content );

			if ( '' === $body ) {
				if ( isset( $overrides[ $key ] ) ) {
					unset( $overrides[ $key ] );
				}
			} else {
				$overrides[ $key ] = $body;
			}

			update_option( self::OPTION_PROMO_OVERRIDES, $overrides );
		}

	/**
	 * Fetch all promo overrides keyed by vendor-pid.
	 *
	 * @return array
	 */
		public function get_promo_overrides() {
			$overrides = get_option( self::OPTION_PROMO_OVERRIDES, array() );
			return is_array( $overrides ) ? $overrides : array();
		}

	/**
	 * Fetch a single override.
	 *
	 * @param string $vendor Vendor.
	 * @param string $pid    Pid.
	 * @return string
	 */
		public function get_promo_override( $vendor, $pid ) {
			$overrides = $this->get_promo_overrides();
			$key       = $this->build_vps_key( $vendor, $pid );
			return isset( $overrides[ $key ] ) ? (string) $overrides[ $key ] : '';
		}

	/**
	 * Save manual meta overrides.
	 *
	 * @param string $vendor Vendor key.
	 * @param string $pid    Product id.
	 * @param string $content Meta body.
	 */
		public function save_meta_override( $vendor, $pid, $content ) {
			$overrides = $this->get_meta_overrides();
			$key       = $this->build_vps_key( $vendor, $pid );
			$body      = trim( (string) $content );

			if ( '' === $body ) {
				if ( isset( $overrides[ $key ] ) ) {
					unset( $overrides[ $key ] );
				}
			} else {
				$overrides[ $key ] = $body;
			}

			update_option( self::OPTION_META_OVERRIDES, $overrides );
		}

	/**
	 * Fetch meta overrides map.
	 *
	 * @return array
	 */
		public function get_meta_overrides() {
			$overrides = get_option( self::OPTION_META_OVERRIDES, array() );
			return is_array( $overrides ) ? $overrides : array();
		}

	/**
	 * Fetch single meta override.
	 *
	 * @param string $vendor Vendor key.
	 * @param string $pid    Product id.
	 * @return string
	 */
		public function get_meta_override( $vendor, $pid ) {
			$overrides = $this->get_meta_overrides();
			$key       = $this->build_vps_key( $vendor, $pid );
			return isset( $overrides[ $key ] ) ? (string) $overrides[ $key ] : '';
		}

		/**
		 * Build consistent vendor-pid key.
		 *
		 * @param string $vendor Vendor key.
		 * @param string $pid    Product id.
		 * @return string
		 */
		protected function build_vps_key( $vendor, $pid ) {
			return $vendor . '-' . $pid;
		}

		/**
		 * Save promo data.
		 *
		 * @param array $data Promo map.
		 */
		public function save_promo_cache( $data ) {
			update_option( self::OPTION_PROMO_CACHE, $data );
		}

		/**
		 * Retrieve promo cache.
		 *
		 * @return array
		 */
		public function get_promo_cache() {
			$data = get_option( self::OPTION_PROMO_CACHE, array() );
			return is_array( $data ) ? $data : array();
		}

	/**
	 * Persist formatted meta cache.
	 *
	 * @param array $data Cache payload.
	 */
		public function save_meta_cache( $data ) {
			update_option( self::OPTION_META_CACHE, $data );
		}

	/**
	 * Fetch formatted meta cache.
	 *
	 * @return array
	 */
		public function get_meta_cache() {
			$data = get_option( self::OPTION_META_CACHE, array() );
			return is_array( $data ) ? $data : array();
		}

	/**
	 * Persist latest VPS snapshot.
	 *
	 * @param array $data Snapshot payload.
	 */
	public function save_vps_snapshot( $data ) {
		update_option( self::OPTION_VPS_SNAPSHOT, $data );
	}

	/**
	 * Retrieve cached VPS snapshot.
	 *
	 * @return array
	 */
	public function get_vps_snapshot() {
		$data = get_option( self::OPTION_VPS_SNAPSHOT, array() );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Update snapshot availability for a VPS.
	 *
	 * @param string  $vendor    Vendor key.
	 * @param string  $pid       Product id.
	 * @param boolean $available Availability.
	 * @param string  $message   Status message.
	 * @param int     $checked   Timestamp.
	 */
	public function update_vps_snapshot_status( $vendor, $pid, $available, $message, $checked ) {
		$snapshot = $this->get_vps_snapshot();
		foreach ( $snapshot as &$entry ) {
			if ( isset( $entry['vendor'], $entry['pid'] ) && $entry['vendor'] === $vendor && $entry['pid'] === $pid ) {
				$entry['available'] = $available;
				$entry['message']   = $message;
				$entry['checked_at'] = $checked;
				break;
			}
		}
		$this->save_vps_snapshot( $snapshot );
	}

	/**
	 * Update arbitrary snapshot fields for a VPS.
	 *
	 * @param string $vendor Vendor key.
	 * @param string $pid    Product id.
	 * @param array  $fields Field map.
	 */
	public function update_vps_snapshot_fields( $vendor, $pid, $fields ) {
		if ( empty( $fields ) || ! is_array( $fields ) ) {
			return;
		}

		$snapshot = $this->get_vps_snapshot();
		$changed  = false;
		foreach ( $snapshot as &$entry ) {
			if ( isset( $entry['vendor'], $entry['pid'] ) && $entry['vendor'] === $vendor && $entry['pid'] === $pid ) {
				foreach ( $fields as $key => $value ) {
					$entry[ $key ] = $value;
				}
				$changed = true;
				break;
			}
		}

		if ( $changed ) {
			$this->save_vps_snapshot( $snapshot );
		}
	}

	/**
	 * Update cached promo content for a VPS.
	 *
	 * @param string $vendor Vendor key.
	 * @param string $pid    Product id.
	 * @param string $promo  Promo text.
	 * @param string $source Promo source.
	 */
	public function update_vps_snapshot_promo( $vendor, $pid, $promo, $source ) {
		$this->update_vps_snapshot_fields(
			$vendor,
			$pid,
			array(
				'promo'        => $promo,
				'promo_source' => $source,
			)
		);
	}

	/**
	 * Update cached meta display for a VPS.
	 *
	 * @param string $vendor Vendor key.
	 * @param string $pid    Product id.
	 * @param string $meta   Meta display.
	 * @param string $source Meta source.
	 */
	public function update_vps_snapshot_meta( $vendor, $pid, $meta, $source ) {
		$this->update_vps_snapshot_fields(
			$vendor,
			$pid,
			array(
				'meta_display' => $meta,
				'meta_source'  => $source,
			)
		);
	}

		/**
		 * Fetch custom CSS.
		 *
		 * @return string
		 */
		public function get_extra_css() {
			return (string) get_option( self::OPTION_EXTRA_CSS, '' );
		}

		/**
		 * Save custom CSS.
		 *
		 * @param string $css Raw CSS.
		 */
		public function save_extra_css( $css ) {
			update_option( self::OPTION_EXTRA_CSS, (string) $css );
		}

		/**
		 * Return log path.
		 *
		 * @return string
		 */
		public function get_log_path() {
			return $this->log_path;
		}

		/**
		 * Read stored logs (applies pruning).
		 *
		 * @return array
		 */
		public function get_logs() {
			$logs = $this->read_log_entries();
			return $this->prune_and_save_logs( $logs );
		}

		/**
		 * Append a log entry and prune based on config.
		 *
		 * @param string $level   Level (info|error|success).
		 * @param string $message Message body.
		 * @return array
		 */
		public function append_log( $level, $message ) {
			$logs   = $this->read_log_entries();
			$logs[] = array(
				'ts'      => time(),
				'level'   => $level,
				'message' => $message,
			);

			return $this->prune_and_save_logs( $logs );
		}

		/**
		 * Apply pruning rules then persist logs.
		 *
		 * @param array $logs Raw entries.
		 * @return array
		 */
		protected function prune_and_save_logs( $logs ) {
			$settings = $this->get_log_settings();
			$logs     = $this->apply_time_limit( $logs, $settings['time_limit'] );
			$logs     = $this->apply_size_limit( $logs, $settings['size_limit'] );
			$this->write_logs( $logs );
			return $logs;
		}

		/**
		 * Load raw logs from file.
		 *
		 * @return array
		 */
		protected function read_log_entries() {
			if ( ! file_exists( $this->log_path ) ) {
				return array();
			}

			$lines = file( $this->log_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
			if ( ! $lines ) {
				return array();
			}

			$result = array();
			foreach ( $lines as $line ) {
				$decoded = json_decode( $line, true );
				if ( isset( $decoded['ts'], $decoded['message'], $decoded['level'] ) ) {
					$result[] = $decoded;
				}
			}

			return $result;
		}

		/**
		 * Persist logs to disk.
		 *
		 * @param array $logs Log entries.
		 */
		protected function write_logs( $logs ) {
			if ( empty( $logs ) ) {
				if ( file_exists( $this->log_path ) ) {
					file_put_contents( $this->log_path, '' );
				}
				return;
			}

			$body = array();
			foreach ( $logs as $entry ) {
				$body[] = wp_json_encode(
					array(
						'ts'      => isset( $entry['ts'] ) ? (int) $entry['ts'] : time(),
						'level'   => isset( $entry['level'] ) ? (string) $entry['level'] : 'info',
						'message' => isset( $entry['message'] ) ? (string) $entry['message'] : '',
					)
				);
			}

			$this->write_file( $this->log_path, implode( "\n", $body ) );
		}

		/**
		 * Extract log-related settings from config.
		 *
		 * @return array
		 */
		public function get_log_settings() {
			$config = $this->get_config();
			$log    = isset( $config['log'] ) && is_array( $config['log'] ) ? $config['log'] : array();

			return array(
				'size_limit' => isset( $log['log_size_limit'] ) ? $this->parse_size_limit( $log['log_size_limit'] ) : null,
				'time_limit' => isset( $log['log_time_limit'] ) ? $this->parse_time_limit( $log['log_time_limit'] ) : null,
			);
		}

		/**
		 * Parse human readable size (supports K/M/G).
		 *
		 * @param string $raw Raw value.
		 * @return int|null
		 */
		protected function parse_size_limit( $raw ) {
			$raw = trim( (string) $raw );
			if ( '' === $raw ) {
				return null;
			}

			if ( ! preg_match( '/^([0-9]+)([kmg])?b?$/i', $raw, $matches ) ) {
				return null;
			}

			$value = (int) $matches[1];
			$unit  = isset( $matches[2] ) ? strtolower( $matches[2] ) : '';
			switch ( $unit ) {
				case 'g':
					return $value * 1024 * 1024 * 1024;
				case 'm':
					return $value * 1024 * 1024;
				case 'k':
					return $value * 1024;
				default:
					return $value;
			}
		}

		/**
		 * Parse human friendly time (s/h/d/w/m/y; m=month).
		 *
		 * @param string $raw Raw value.
		 * @return int|null
		 */
		protected function parse_time_limit( $raw ) {
			$raw = strtolower( trim( (string) $raw ) );
			if ( '' === $raw ) {
				return null;
			}

			if ( ! preg_match( '/^([0-9]+)([shdwmy])$/', $raw, $matches ) ) {
				return null;
			}

			$value = (int) $matches[1];
			$unit  = $matches[2];
			switch ( $unit ) {
				case 's':
					return $value;
				case 'h':
					return $value * HOUR_IN_SECONDS;
				case 'd':
					return $value * DAY_IN_SECONDS;
				case 'w':
					return $value * WEEK_IN_SECONDS;
				case 'm':
					return $value * DAY_IN_SECONDS * 30; // treat m as month (approx).
				case 'y':
					return $value * DAY_IN_SECONDS * 365;
				default:
					return null;
			}
		}

		/**
		 * Drop entries older than limit.
		 *
		 * @param array    $logs  Entries.
		 * @param int|null $limit Seconds.
		 * @return array
		 */
		protected function apply_time_limit( $logs, $limit ) {
			if ( null === $limit || $limit <= 0 ) {
				return $logs;
			}

			$threshold = time() - $limit;
			return array_values(
				array_filter(
					$logs,
					function ( $entry ) use ( $threshold ) {
						return isset( $entry['ts'] ) && (int) $entry['ts'] >= $threshold;
					}
				)
			);
		}

		/**
		 * Trim oldest entries to fit size limit.
		 *
		 * @param array    $logs  Entries.
		 * @param int|null $limit Bytes.
		 * @return array
		 */
		protected function apply_size_limit( $logs, $limit ) {
			if ( null === $limit || $limit <= 0 ) {
				return $logs;
			}

			// Keep trimming oldest until size fits.
			while ( count( $logs ) > 1 && $this->estimate_logs_size( $logs ) > $limit ) {
				array_shift( $logs );
			}

			// If still too large, keep the last entry only.
			if ( $this->estimate_logs_size( $logs ) > $limit && ! empty( $logs ) ) {
				$logs = array( end( $logs ) );
			}

			return array_values( $logs );
		}

		/**
		 * Approximate serialized size (JSON lines).
		 *
		 * @param array $logs Entries.
		 * @return int
		 */
		protected function estimate_logs_size( $logs ) {
			$total = 0;
			foreach ( $logs as $entry ) {
				$total += strlen(
					wp_json_encode(
						array(
							'ts'      => isset( $entry['ts'] ) ? (int) $entry['ts'] : time(),
							'level'   => isset( $entry['level'] ) ? (string) $entry['level'] : 'info',
							'message' => isset( $entry['message'] ) ? (string) $entry['message'] : '',
						)
					)
				);
			}

			// Add newline separators.
			$total += max( 0, count( $logs ) - 1 );
			return $total;
		}
	}
}
